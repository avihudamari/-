package renderer;

import elements.AmbientLight;
import elements.Camera;
import elements.PointLight;
import elements.SpotLight;
import geometries.Geometry;
import geometries.Plane;
import geometries.Sphere;
import geometries.Triangle;
import org.junit.Test;
import primitives.Material;
import primitives.Ray;
import primitives.Vector;
import primitives.point3D;
import scene.Scene;

import java.awt.*;
import java.util.List;

import static org.junit.Assert.*;
public class RenderTest {
    @Test
    public void basicRendering() {
        ImageWriter writer = new ImageWriter("rendertest_tabale", 500, 500, 500, 500);
        AmbientLight ambientLight = new AmbientLight(255, 255, 255);
        Camera camera = new Camera(new point3D(0, 0, 0), new Vector(0, 1, 0), new Vector(0, 0, -1));
        Scene scene = new Scene(ambientLight, new Color(0, 0, 0), camera, 10);
        Triangle triangle = new Triangle(new point3D(-50, 30, -40), new point3D(-40, 30, -40), new point3D(-40, 30, -60));
        triangle.setEmmission(new Color(100, 255, 255));
        Triangle triangle12 = new Triangle(new point3D(-50, 30, 60), new point3D(-20, 30, 40), new point3D(-40, 30, 60));
        triangle12.setEmmission(new Color(200, 250, 25));
        scene.addGeometry(triangle);
        scene.addGeometry(triangle12);
        scene.setScreenDistance(150);

        Render render = new Render(writer, scene);
        render.renderImage();
        render.writeToImage();


    }
    @Test
    public void recursiveTest() {

        Scene scene = new Scene();
        scene.setScreenDistance(300);

        Sphere sphere = new Sphere(500, new point3D(0.0, 0.0, -1000));
        sphere.setShininess(20);
        sphere.setEmmission(new Color(0, 0, 100));
        sphere.setKt(0.5);
        scene.addGeometry(sphere);
        Sphere sphere2 = new Sphere(250, new point3D(0.0, 0.0, -1000));
        sphere2.setShininess(20);
        sphere2.setEmmission(new Color(100, 20, 20));
        sphere2.setKt(0);
        scene.addGeometry(sphere2);
        scene.addLight(new SpotLight(new Color(255, 100, 100), new Vector(2, 2, -3),
                new point3D(-200, -200, -150), 0.1, 0.00001, 0.000005));
        ImageWriter imageWriter = new ImageWriter("Recursive Test", 500, 500, 500, 500);
        Render render = new Render(imageWriter, scene);
        render.renderImage();
        render.writeToImage();
    }
    @Test
    public void recursiveTest2() {

        Scene scene = new Scene();
        scene.setScreenDistance(300);
        Sphere sphere = new Sphere(300, new point3D(-550, -500, -1000));
        sphere.setShininess(20);
        sphere.setEmmission(new Color(0, 0, 100));
        sphere.setKt(0.5);
        scene.addGeometry(sphere);

        Sphere sphere2 = new Sphere(150, new point3D(-550, -500, -1000));
        sphere2.setShininess(20);
        sphere2.setEmmission(new Color(100, 20, 20));
        sphere2.setKt(0);
        scene.addGeometry(sphere2);

        Triangle triangle = new Triangle(new point3D(1500, -1500, -1500),
                new point3D(-1500, 1500, -1500),
                new point3D(200, 200, -375));

        Triangle triangle2 = new Triangle(new point3D(1500, -1500, -1500),
                new point3D(-1500, 1500, -1500),
                new point3D(-1500, -1500, -1500));

        triangle.setEmmission(new Color(20, 20, 20));
        triangle2.setEmmission(new Color(20, 20, 20));
        scene.addGeometry(triangle);
        scene.addGeometry(triangle2);

        scene.addLight(new SpotLight(new Color(255, 100, 100), new Vector(-2, -2, -3),
                new point3D(200, 200, -150), 0, 0.00001, 0.000005));

        ImageWriter imageWriter = new ImageWriter("Recursive Test 2", 500, 500, 500, 500);

        Render render = new Render(imageWriter, scene);

        render.renderImage();
        render.writeToImage();

    }
    @Test
    public void table() {
        Scene scene = new Scene();
        scene.setScreenDistance(50);
        scene.setCamera(new Camera(new point3D(100, -50, 0), new Vector(1D, 0, 0), new Vector(0, 0, -1)));
        Plane floor = new Plane(new Vector(-1, 0, 0), new point3D(-200, 0, 0));
        floor.setEmmission(new Color(100, 100, 100));
        scene.setBackground(new Color(51, 153, 255));
        Triangle triangle1 = new Triangle(
                new point3D(0, 100, -100),
                new point3D(0, 100, -50),
                new point3D(0, -100, -50));
        Triangle triangle2 = new Triangle(
                new point3D(0, 100, -100),
                new point3D(0, -100, -100),
                new point3D(0, -100, -50));
        triangle1.setEmmission(new java.awt.Color(205, 133, 63));
        triangle2.setEmmission(new java.awt.Color(205, 133, 63));
        triangle1.setShininess(20);
        triangle2.setShininess(20);
        scene.addGeometry(triangle1);
        scene.addGeometry(triangle2);
        scene.addGeometry(floor);
        ImageWriter imageWriter = new ImageWriter("tabletest", 500, 500, 500, 500);
        Render render = new Render(imageWriter, scene);
        render.renderImage();
        render.writeToImage();
    }
}









